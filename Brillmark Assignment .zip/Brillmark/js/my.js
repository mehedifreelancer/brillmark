$(document).ready(function(){
    $('.all_slider_items').slick({
      slidesToShow: 1,
slidesToScroll: 1,
arrows: false,
dots:true,
autoplay:true

   });
});

$(document).ready(function(){
    $('.second_slider').slick({
      slidesToShow: 1,
slidesToScroll: 1,
arrows: false,
dots:true

   });
});


// ---------------------------------Code for customizing slider dots----------------------------------
